﻿using Proiect_II_Auth.Models;

namespace Proiect_II_Auth.Data.repo
{
    public interface IReservationRepo
    {
        Task addReservation(Reservation reservation);
        Task<List<Reservation>> GetReservationsByUserId(string id);
        Task<List<Reservation>> GetReservations();

        Task<bool> EventExists(string eventName);
    }
}
