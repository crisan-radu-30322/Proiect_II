﻿using Microsoft.Extensions.Logging;
using Proiect_II_Auth.Models;

namespace Proiect_II_Auth.Data.repo
{
    public interface IEventRepository
    {
        Task<List<Events>> getAllEvents(CancellationToken token);
        Task addEvent(Events newEvent);
        Task deleteEvent(string eventName);
        Task<bool> EventExists(string eventName);
        Task<Events> GetEventByName(string eventName);
        Task UpdateEvent(Events updatedEvent);
    }
}
