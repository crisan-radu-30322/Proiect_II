﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Proiect_II_Auth.Data.repo;
using Proiect_II_Auth.Models;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Proiect_II_Auth.Controllers
{
    [Authorize]
    public class ReservationController : Controller
    {
        private readonly IReservationRepo _reservationRepo;
        private readonly IEventRepository _eventRepository;

        public ReservationController(IReservationRepo reservationRepo, IEventRepository eventRepository)
        {
            _reservationRepo = reservationRepo;
            _eventRepository = eventRepository;
        }

        public ActionResult AddReservation()
        {
            return View("AddReservation");
        }

        [HttpPost]
        public async Task<ActionResult> AddReservation(Reservation reservation)
        {
            if (ModelState.IsValid)
            {
                // Check if the event exists
                var eventExists = await _eventRepository.EventExists(reservation.eventName);
                if (!eventExists)
                {
                    ModelState.AddModelError("eventName", "The specified event does not exist.");
                    return View("AddReservation", reservation);
                }

                var eventDetails = await _eventRepository.GetEventByName(reservation.eventName);
                if (eventDetails == null)
                {
                    ModelState.AddModelError("eventName", "The specified event does not exist.");
                    return View("AddReservation", reservation);
                }

                // Check ticket availability
                switch (reservation.ticketType)
                {
                    case "Standard":
                        if (eventDetails.StandardTicket <= 0)
                        {
                            ModelState.AddModelError("ticketType", "No Standard tickets available.");
                            return View("AddReservation", reservation);
                        }
                        eventDetails.StandardTicket--;
                        break;

                    case "Premium":
                        if (eventDetails.PremiumTicket <= 0)
                        {
                            ModelState.AddModelError("ticketType", "No Premium tickets available.");
                            return View("AddReservation", reservation);
                        }
                        eventDetails.PremiumTicket--;
                        break;

                    case "VIP":
                        if (eventDetails.VIPTicket <= 0)
                        {
                            ModelState.AddModelError("ticketType", "No VIP tickets available.");
                            return View("AddReservation", reservation);
                        }
                        eventDetails.VIPTicket--;
                        break;

                    default:
                        ModelState.AddModelError("ticketType", "Invalid ticket type.");
                        return View("AddReservation", reservation);
                }

                // Update the event with the new ticket counts
                await _eventRepository.UpdateEvent(eventDetails);

                // Create and save the reservation
                Reservation r = new Reservation
                {
                    userId = User.FindFirstValue(ClaimTypes.NameIdentifier),
                    eventName = reservation.eventName,
                    ticketOwnerName = reservation.ticketOwnerName,
                    ticketType = reservation.ticketType
                };

                await _reservationRepo.addReservation(r);

                TempData["SuccessMessage"] = "Reservation successfully submitted!";
                return RedirectToAction("AddReservation");
            }

            return View("AddReservation", reservation);
        }


        public async Task<IActionResult> ReservationHistory()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;
            var reservations = await _reservationRepo.GetReservationsByUserId(userId);
            return View(reservations);
        }

        public async Task<IActionResult> GetAllReservations()
        {
            var reservations = await _reservationRepo.GetReservations();
            return View(reservations);
        }
    }
}
