﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect_II_Auth.Data.repo;
using Proiect_II_Auth.Models;
using Proiect_II_Auth.Services;
using System.IO;
using System.Threading.Tasks;
using System.Web;

namespace Proiect_II_Auth.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ModifyEventController : Controller
    {
        private readonly IEventRepository _eventRepository;

        public ModifyEventController(IEventRepository eventRepository)
        {
            _eventRepository = eventRepository;
        }

        public ActionResult DeleteEvent()
        {
            return View("DeleteEvent");
        }

        public ActionResult AddEvent()
        {
            return View("AddEvent");
        }
        public ActionResult UpdateEvent(string eventName)
        {
            return View("UpdateEvent");
        }


        [HttpPost]
        public async Task<ActionResult> AddEvent(Events model)
        {
            if (ModelState.IsValid)
            {
                Events newEvent = new Events();
                newEvent.EventName = model.EventName;
                newEvent.EventDescription = model.EventDescription;
                newEvent.EventLocation = model.EventLocation;
                newEvent.StandardTicket = model.StandardTicket;
                newEvent.PremiumTicket = model.PremiumTicket;
                newEvent.VIPTicket = model.VIPTicket;


                await _eventRepository.addEvent(newEvent);

                TempData["SuccessMessage"] = "Event added successfully!";


                return RedirectToAction("AddEvent");
            }

            return View();
        }
        [HttpPost]
        public async Task<ActionResult> UpdateEvent(Events model)
        {
            if (ModelState.IsValid)
            {
                var existingEvent = await _eventRepository.GetEventByName(model.EventName);
                if (existingEvent == null)
                {
                    TempData["ErrorMessage"] = "Event not found!";
                    return RedirectToAction("UpdateEvent");
                }

                existingEvent.EventDescription = model.EventDescription;
                existingEvent.EventLocation = model.EventLocation;
                existingEvent.StandardTicket = model.StandardTicket;
                existingEvent.PremiumTicket = model.PremiumTicket;
                existingEvent.VIPTicket = model.VIPTicket;
               

                await _eventRepository.UpdateEvent(existingEvent);

                TempData["SuccessMessage"] = "Event updated successfully!";
                return RedirectToAction("UpdateEvent", new { eventName = model.EventName });
            }

            return View();
        }


        [HttpPost]
        public async Task<IActionResult> deleteEvent(string eventName)
        {
            if (String.IsNullOrEmpty(eventName))
            {
                ModelState.AddModelError(string.Empty, $"Error deleting event");
                TempData["ErrorMessage"] = "Error deleting the event" + eventName;
            }
            else
            {
                try
                {
                    await _eventRepository.deleteEvent(eventName);
                    TempData["SuccessMessage"] = "Event has been deleted successfully!";
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Event " + eventName + " cannot be found!";
                }

            }
            return View("DeleteEvent");
        }

    }
}
