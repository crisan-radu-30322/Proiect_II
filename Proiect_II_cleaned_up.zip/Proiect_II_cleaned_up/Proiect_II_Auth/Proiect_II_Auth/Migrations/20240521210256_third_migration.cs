﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProiectIIAuth.Migrations
{
    /// <inheritdoc />
    public partial class thirdmigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "PremiumTicket",
                table: "Events",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "StandardTicket",
                table: "Events",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "VIPTicket",
                table: "Events",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PremiumTicket",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "StandardTicket",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "VIPTicket",
                table: "Events");
        }
    }
}
