﻿using ProiectII.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace ProiectII.Data
{
    public class ProiectIIDbContext : DbContext
    {
        public ProiectIIDbContext(DbContextOptions options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Booking> Booking { get; set; }
        public DbSet<Ticket> Ticket { get; set; }
        public DbSet<TicketType> TicketType { get; set; }
        public DbSet<Event> Event { get; set; }

        
    }
}
