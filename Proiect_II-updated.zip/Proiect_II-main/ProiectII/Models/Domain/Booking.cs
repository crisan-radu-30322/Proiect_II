﻿namespace ProiectII.Models.Domain
{
    public class Booking
    {
        public Guid BookingId { get; set; }
        public DateTime BookingDate { get; set; }
        public int BookingQuantity { get; set; }

        public Guid UserId { get; set; }
        public User User { get; set; }

        public Guid TicketId { get; set; }
        public Ticket Ticket { get; set; }
    }
}
