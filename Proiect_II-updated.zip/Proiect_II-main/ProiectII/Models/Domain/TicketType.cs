﻿namespace ProiectII.Models.Domain
{
    public class TicketType
    {
        public Guid TicketTypeId { get; set; }
        public string TicketTypeName { get; set; }
        public string TicketTypeDescription { get; set; }
        public int TicketTypePrice {  get; set; }
    }
}
