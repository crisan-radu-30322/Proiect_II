﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect_II_Auth.Data;
using Proiect_II_Auth.Data.repo;
using System.Linq;

namespace Proiect_II_Auth.Controllers
{
    public class EventController : Controller
    {
        private readonly IEventRepository _eventRepository;

        public EventController(IEventRepository eventRepository)
        {
            _eventRepository = eventRepository;
        }

        public async Task<IActionResult> GetAll(CancellationToken token)
        {
            var events = await _eventRepository.getAllEvents(token);
            return View(events);
        }

    }
}
