﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Proiect_II_Auth.Controllers
{
    [Authorize(Roles ="Admin")]
    public class Modify_EventController : Controller
    {
        public IActionResult GetAll()
        {
            return View();
        }
    }
}
