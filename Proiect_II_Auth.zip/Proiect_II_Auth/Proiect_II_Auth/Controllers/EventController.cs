﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Proiect_II_Auth.Controllers
{
    public class EventController : Controller
    {
        public IActionResult GetAll()
        {
            return View();
        }
    }
}
