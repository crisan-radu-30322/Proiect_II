﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Proiect_II_Auth.Data.repo;
using Proiect_II_Auth.Models;
using System.Threading.Tasks;

namespace Proiect_II_Auth.Controllers
{
    [Authorize] // Ensure that only authenticated users can access this controller
    public class ReservationController : Controller
    {
        private readonly IReservationRepo _reservationRepo;

        public ReservationController(IReservationRepo reservationRepo)
        {
            _reservationRepo = reservationRepo;
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Index(Reservation reservation)
        {
            if (ModelState.IsValid)
            {
                // Directly use the reservation parameter
                await _reservationRepo.addReservation(reservation);

                TempData["SuccessMessage"] = "Reservation successfully submitted!";

                return RedirectToAction("Index");
            }

            return View(reservation); // Return the model to preserve user input
        }
    }
}
