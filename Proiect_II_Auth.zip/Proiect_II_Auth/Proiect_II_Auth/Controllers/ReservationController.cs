﻿using Microsoft.AspNetCore.Mvc;
using Proiect_II_Auth.Data.repo;
using Proiect_II_Auth.Models;

namespace Proiect_II_Auth.Controllers
{
    public class ReservationController : Controller
    {
        private readonly IReservationRepo _reservationRepo;

        public ReservationController(IReservationRepo reservation)
        {
            this._reservationRepo = reservation;
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Index(Reservation reservation)
        {
            Reservation r = new Reservation();
            r.eventName = reservation.eventName;    
            r.ticketOwnerName= reservation.ticketOwnerName;
            r.ticketType = reservation.ticketType;

            if (ModelState.IsValid)
            {

                await _reservationRepo.addReservation(r);

                TempData["SuccessMessage"] = "Reservation successfully submitted!";

                return RedirectToAction("Index");
            }

            return View();
        }
    }
}
