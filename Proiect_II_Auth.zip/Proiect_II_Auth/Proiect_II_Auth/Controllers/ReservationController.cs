﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Proiect_II_Auth.Data.repo;
using Proiect_II_Auth.Models;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Proiect_II_Auth.Controllers
{
    [Authorize] 
    public class ReservationController : Controller
    {
        private readonly IReservationRepo _reservationRepo;

        public ReservationController(IReservationRepo reservationRepo)
        {
            _reservationRepo = reservationRepo;
        }

        public ActionResult AddReservation()
        {
            return View("AddReservation");
        }

        [HttpPost]
        public async Task<ActionResult> AddReservation(Reservation reservation)
        {
            if (ModelState.IsValid)
            {
                Reservation r = new Reservation();
                r.userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                r.eventName = reservation.eventName;
                r.ticketOwnerName = reservation.ticketOwnerName;
                r.ticketType = reservation.ticketType;

                await _reservationRepo.addReservation(r);

                TempData["SuccessMessage"] = "Reservation successfully submitted!";

                return RedirectToAction("AddReservation");
            }

            return View("AddReservation"); 
        }

        public async Task<IActionResult> ReservationHistory()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;
            var reservations = await _reservationRepo.GetReservationsByUserId(userId);
            return View(reservations);
        }

        public async Task<IActionResult> GetAllReservations()
        {
            var reservations = await _reservationRepo.GetReservations();
            return View(reservations);
        }

  
    }
}
