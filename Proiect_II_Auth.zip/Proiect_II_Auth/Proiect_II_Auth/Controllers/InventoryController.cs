﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Proiect_II_Auth.Controllers
{
    [Authorize(Roles ="Admin")]
    public class ModifyEventController : Controller
    {
        public IActionResult GetAll()
        {
            return View();
        }
    }
}
