﻿namespace Proiect_II_Auth.Services
{
    public class Class
    {
    }
}
