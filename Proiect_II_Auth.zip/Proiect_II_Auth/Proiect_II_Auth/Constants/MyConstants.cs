﻿namespace Proiect_II_Auth.Constants
{
    public enum Roles
    {
        Admin, //here are the two roles defined, this is the place where you should add more if you want (but we won't do it)
        User
    }
    public class MyConstants
    {
    }
}
