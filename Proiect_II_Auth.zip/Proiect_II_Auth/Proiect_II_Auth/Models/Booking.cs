﻿using System.Net.Sockets;
using Proiect_II_Auth.Data;

namespace Proiect_II_Auth.Models
{
    public class Booking
    {
        public Guid BookingId { get; set; }
        public DateTime BookingDate { get; set; }
        public int BookingQuantity { get; set; }


        public ApplicationUser User { get; set; }
        public Guid Id { get; set; }
        public Guid TicketId { get; set; }
        public Ticket Ticket { get; set; }
    }
}


