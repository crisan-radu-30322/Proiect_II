﻿using Proiect_II_Auth.Data;
using System.ComponentModel.DataAnnotations;

namespace Proiect_II_Auth.Models
{
    public class Reservation
    {
        [Key]
        public int id { get; set; }
        public string ticketOwnerName { get; set; }
        public string eventName{ get; set; }
        public string ticketType { get; set; }

        public Reservation() {

            Random random = new Random();
            id = random.Next(1,1000000);
                
        }
    }

   
}
