﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Proiect_II_Auth.Models
{
    public class Events
    {
        [Key]
        public Guid EventId { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public string EventLocation { get; set; }

        public Events()
        {
            EventId = Guid.NewGuid();
        }
    }
}
