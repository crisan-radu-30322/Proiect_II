﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Proiect_II_Auth.Data
{
    public class Events
    {
        [Key]
        public Guid EventId { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public string EventLocation { get; set; }

        // Navigation property for related tickets
        public List<Ticket> Tickets { get; set; }
    }
}
