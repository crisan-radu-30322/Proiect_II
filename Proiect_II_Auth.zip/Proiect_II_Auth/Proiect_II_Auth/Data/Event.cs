﻿namespace Proiect_II_Auth.Data
{
    public class Event
    {
        public Guid EventId { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }

        public string EventLocation { get; set; }
    }
}
