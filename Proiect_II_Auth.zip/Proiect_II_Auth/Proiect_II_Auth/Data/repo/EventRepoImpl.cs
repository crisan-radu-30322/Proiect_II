﻿
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Proiect_II_Auth.Models;

namespace Proiect_II_Auth.Data.repo
{
    public class EventRepoImpl : IEventRepository
    {
        public ApplicationDbContext _context;
        public EventRepoImpl(ApplicationDbContext context) {
            _context = context;
        }

        public async Task<List<Events>> getAllEvents(CancellationToken token)
        {
             return await _context.Events.ToListAsync(token);
        }

        public async Task deleteEvent(string eventName)
        {
            var existingEvent = await _context.Events.FirstOrDefaultAsync(e => e.EventName == eventName);
            if (existingEvent != null)
            {
                _context.Events.Remove(existingEvent);
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Event cannot be found!");
            }
        }

        public async Task addEvent(Events newEvent)
        {
            await _context.Events.AddAsync(newEvent);
            await _context.SaveChangesAsync();
        }
    }
}
