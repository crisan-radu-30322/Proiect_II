﻿
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;

namespace Proiect_II_Auth.Data.repo
{
    public class EventRepoImpl : IEventRepository
    {
        public ApplicationDbContext _context;
        public EventRepoImpl(ApplicationDbContext context) {
            _context = context;
        }

        public async Task<List<Events>> getAllEvents(CancellationToken token)
        {
             return await _context.Events.ToListAsync(token);
        }
    }
}
