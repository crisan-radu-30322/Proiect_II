﻿using Microsoft.EntityFrameworkCore;
using Proiect_II_Auth.Models;

namespace Proiect_II_Auth.Data.repo
{
    public class ReservationRepoImpl : IReservationRepo
    {
        ApplicationDbContext _context;
        public ReservationRepoImpl(ApplicationDbContext context) {
            this._context = context;
        }

        public async Task addReservation(Reservation reservation)
        {
            await _context.Reservation.AddAsync(reservation);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Reservation>> GetReservations()
        {
            return await _context.Reservation.ToListAsync();
        }

        public async Task<List<Reservation>> GetReservationsByUserId(string userId)
        {
            return await _context.Reservation
                .Where(r => r.userId == userId)
                .ToListAsync();
        }

    }
}
