﻿namespace Proiect_II_Auth.Data.repo
{
    public interface IEventRepository
    {
        Task <List<Events>> getAllEvents(CancellationToken token);
    }
}
