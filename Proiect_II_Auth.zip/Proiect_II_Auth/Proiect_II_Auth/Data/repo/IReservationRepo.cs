﻿using Proiect_II_Auth.Models;

namespace Proiect_II_Auth.Data.repo
{
    public interface IReservationRepo
    {
        Task addReservation(Reservation reservation);
    }
}
