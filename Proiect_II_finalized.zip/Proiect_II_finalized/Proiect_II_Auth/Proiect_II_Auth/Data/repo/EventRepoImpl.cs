﻿using Microsoft.EntityFrameworkCore;
using Proiect_II_Auth.Models;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Proiect_II_Auth.Data.repo
{
    public class EventRepoImpl : IEventRepository
    {
        private readonly ApplicationDbContext _context;

        public EventRepoImpl(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Events>> getAllEvents(CancellationToken token)
        {
            return await _context.Events.ToListAsync(token);
        }

        public async Task deleteEvent(string eventName)
        {
            var existingEvent = await _context.Events.FirstOrDefaultAsync(e => e.EventName == eventName);
            if (existingEvent != null)
            {
                _context.Events.Remove(existingEvent);
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Event cannot be found!");
            }
        }

        public async Task addEvent(Events newEvent)
        {
            await _context.Events.AddAsync(newEvent);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> EventExists(string eventName)
        {
            return await _context.Events.AnyAsync(e => e.EventName == eventName);
        }
        public async Task<Events> GetEventByName(string eventName)
        {
            return await _context.Events.FirstOrDefaultAsync(e => e.EventName == eventName);
        }

        public async Task UpdateEvent(Events updatedEvent)
        {
            _context.Events.Update(updatedEvent);
            await _context.SaveChangesAsync();
        }

    }
}
