﻿using Microsoft.Extensions.Logging;
using System.Net.Sockets;

namespace Proiect_II_Auth.Models
{
   public class Ticket
        {
            public Guid TicketId { get; set; }
            public int TotalQuantity { get; set; }
            public int AvailableQuantity { get; set; }

            public Guid EventId { get; set; }
            public Events Event { get; set; }

            public Guid TicketTypeId { get; set; }
            public TicketType TicketType { get; set; }
        }
}
