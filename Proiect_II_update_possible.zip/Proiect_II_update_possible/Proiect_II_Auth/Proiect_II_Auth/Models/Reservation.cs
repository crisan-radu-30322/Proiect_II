﻿using Proiect_II_Auth.Data;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;

namespace Proiect_II_Auth.Models
{
    public class Reservation
    {
        [Key]
        public Guid id { get; set; }
        public string userId { get; set; }
        public string ticketOwnerName { get; set; }
        public string eventName{ get; set; }
        public string ticketType { get; set; }
       

        public Reservation() {

            this.id = new Guid();
            this.userId = "undefined";
            this.ticketOwnerName = "undefined";
            this.eventName = "undefined";
            this.ticketType = "undefined";
        }
    }

   
}
