﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Numerics;

namespace Proiect_II_Auth.Models
{
    public class Events
    {
        [Key]
        public Guid EventId { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public string EventLocation { get; set; }

        public int StandardTicket {  get; set; }

        public int PremiumTicket { get; set; }

        public int VIPTicket { get; set; }


        public Events()
        {
            EventId = Guid.NewGuid();
        }
    }
}
